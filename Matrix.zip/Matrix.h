#ifndef MATRIX_H
#define MATRIX_H

class Matrix {
public:
    void MatrixInput();
    void addMatrix();
    void subMatrix();
    void mulMatrix();

private:
    int a[10][10];
    int b[10][10];
    int c[10][10];
    int n;
};

#endif
