#include <iostream>
#include "Matrix.h"
using namespace std;

void Matrix::MatrixInput() {
    cout << "Enter the size of the square matrix: ";
    cin >> n;

    cout << "Enter Matrix A:\n";
    for(int i = 0; i < n; ++i)
        for(int j = 0; j < n; ++j)
            cin >> a[i][j];

    cout << "Enter Matrix B:\n";
    for(int i = 0; i < n; ++i)
        for(int j = 0; j < n; ++j)
            cin >> b[i][j];
}

void Matrix::addMatrix() {
    cout << "Addition:\n";
    for(int i = 0; i < n; ++i) {
        for(int j = 0; j < n; ++j) {
            c[i][j] = a[i][j] + b[i][j];
            cout << c[i][j] << " ";
        }
        cout << endl;
    }
}

void Matrix::subMatrix() {
    cout << "Subtraction:\n";
    for(int i = 0; i < n; ++i) {
        for(int j = 0; j < n; ++j) {
            c[i][j] = a[i][j] - b[i][j];
            cout << c[i][j] << " ";
        }
        cout << endl;
    }
}

void Matrix::mulMatrix() {
    cout << "Multiplication:\n";
    for(int i = 0; i < n; ++i)
        for(int j = 0; j < n; ++j)
            c[i][j] = 0;

    for(int i = 0; i < n; ++i)
        for(int j = 0; j < n; ++j)
            for(int k = 0; k < n; ++k)
                c[i][j] += a[i][k] * b[k][j];

    for(int i = 0; i < n; ++i) {
        for(int j = 0; j < n; ++j)
            cout << c[i][j] << " ";
        cout << endl;
    }
}
